
<div align="center">

<img src="./docs/imgs/oligo_logo.png">

</div>

# seqtools
seq process tools

## install

github

```
git clone git@github.com:iOLIGO/SeqTools.git
pip install dist/SeqTools-1.0.0.tar.gz
```

## functions

- 