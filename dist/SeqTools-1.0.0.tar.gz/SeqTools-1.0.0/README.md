
<div align="center">

<img src="./docs/imgs/oligo_logo.png">

</div>

# seqtools
seq process tools

## install

github

```
pip install dist/SeqTools-1.0.0.tar.gz
```