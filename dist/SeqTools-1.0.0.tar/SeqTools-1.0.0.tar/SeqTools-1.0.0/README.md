
<div align="center">

<img src="./docs/imgs/oligo_logo.png">

</div>

# seqtools
seq process tools
